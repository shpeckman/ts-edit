// vendor/deps/tree-sitter-lib/src/wasm-stdlib/libc/string/strchr.c
#include <string.h>

char *strchr(const char *s, int c)
{
	char *r = __strchrnul(s, c);
	return *(unsigned char *)r == (unsigned char)c ? r : 0;
}
