// vendor/deps/tree-sitter-lib/src/wasm-stdlib/libc/string/strncpy.c
#include <string.h>

char *strncpy(char *restrict d, const char *restrict s, size_t n)
{
	__stpncpy(d, s, n);
	return d;
}
