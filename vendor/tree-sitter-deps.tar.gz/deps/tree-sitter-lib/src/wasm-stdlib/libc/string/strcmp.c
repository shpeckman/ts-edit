// vendor/deps/tree-sitter-lib/src/wasm-stdlib/libc/string/strcmp.c
#include <string.h>

int strcmp(const char *l, const char *r)
{
	for (; *l==*r && *l; l++, r++);
	return *(unsigned char *)l - *(unsigned char *)r;
}
