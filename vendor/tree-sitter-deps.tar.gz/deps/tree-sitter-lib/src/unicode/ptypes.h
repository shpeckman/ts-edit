// vendor/deps/tree-sitter-lib/src/unicode/ptypes.h
// This file must exist in order for `utf8.h` and `utf16.h` to be used.
